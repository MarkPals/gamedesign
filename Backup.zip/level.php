<!DOCTYPE html>
<HTML>
<HEAD>
<META content="text/html; charset=utf-8" http-equiv="Content-Type" />
<LINK href="style.css" rel="stylesheet" type="text/css" />
<TITLE>Gamepjuh</TITLE>
</HEAD>
<BODY>
    
    <h1>Gamepjuh</h1>
    <div id="test">             <!-- Blok waar de game in komt te staan -->
                                            
<!--                                            levelpagina-->
                <div id="level">   
                    <?php echo $naam;
                    ?>
                    <a href="level1.php"><img src="media/test.jpg"> </a>
                    <a href="level2.php"><img src="media/test.jpg"> </a>
                    <a href="level3.php"><img src="media/test.jpg"> </a>
                </div>
    </div>

 

    
</BODY>
</HTML>